clc
clear

pro=29;
trial=25; %运行次数
num=1000;% 保留结果数目
SR=[];
score=[];
for i = 1:pro

    filename=['F:\各文档\班旋旋\师爷技术报告\CEC2025\Results-BC-SOPs\BlockEA\BlockEA_F', num2str(i), '_Min_EV.mat' ];
    load(filename);
    T1=combinedMatrix(2:num+1,:);    %1000是保留结果数目
    
    filename=['F:\各文档\班旋旋\师爷技术报告\CEC2025\Results-BC-SOPs\IEACOP\#1570992402_F', num2str(i), '_Min_EV.mat' ];
    load(filename);
    T2=Min_EV(1:num,:);
    
    filename=['F:\各文档\班旋旋\师爷技术报告\CEC2025\Results-BC-SOPs\RDE\RDE_F', num2str(i), '_Min_EV.mat' ];
    load(filename);
    T3=data(1:num,:);
    
    filename=['F:\各文档\班旋旋\师爷技术报告\CEC2025\Results-BC-SOPs\mLSHADE_LR\mLSAHDE_LR_F#', num2str(i), '_D#30.mat' ];
    T4=load(filename,'-ASCII');
    T4=T4(1:num,:);
    
    filename=['F:\各文档\班旋旋\师爷技术报告\CEC2025\Results-BC-SOPs\L-SRTDE\L-SRTDE_F', num2str(i), '_D30.txt' ];
    T5=load(filename)';
    T5=T5(2:num+1,:);
    
    if i ==1
        filename=['F:\各文档\班旋旋\师爷技术报告\CEC2025\Results-BC-SOPs\jSOa\jSOa_D30_S', num2str(i), '.txt' ];
        T6=load(filename);
        T6=T6(1:num,:);
    else
        filename=['F:\各文档\班旋旋\师爷技术报告\CEC2025\Results-BC-SOPs\jSOa\jSOa_D30_S', num2str(i+1), '.txt' ];
        T6=load(filename);
        T6=T6(1:num,:);
    end
    
    cf=trial*(trial+1)/2;   %计算cf，这里的运行次数是1000
    
    USCORE=[];
    final=[T1(end,:),T2(end,:),T3(end,:),T4(end,:),T5(end,:),T6(end,:)];
    TGT=mean(final);
    
    rank=[];
    archive1=[];
    archive2=[];
    archive3=[];
    archive4=[];
    archive5=[];
    archive6=[];
    for k = 1:25  
        if isempty((find(T1(:,k)<=TGT))) || T1(end-1,k) >TGT
            FE1=num;
            archive1=[archive1,T1(end,k)];
        else
            FE1=min((find(T1(:,k)<=TGT)));
        end
        
        if isempty((find(T2(:,k)<=TGT)))|| T2(end-1,k) >TGT
            FE2=num;
            archive2=[archive2,T2(end,k)];
        else
            FE2=min((find(T2(:,k)<=TGT)));
        end
        
        if isempty((find(T3(:,k)<=TGT)))|| T3(end-1,k) >TGT
            FE3=num;
            archive3=[archive3,T3(end,k)];
        else
            FE3=min((find(T3(:,k)<=TGT)));
        end
        
        if isempty((find(T4(:,k)<=TGT)))|| T4(end-1,k) >TGT
            FE4=num;
            archive4=[archive4,T4(end,k)];
        else
            FE4=min((find(T4(:,k)<=TGT)));
        end
        
        if isempty((find(T5(:,k)<=TGT))) || T5(end-1,k) >TGT
            FE5=num;
            archive5=[archive5,T5(end,k)];
        else
            FE5=min((find(T5(:,k)<=TGT)));
        end
        
         if isempty((find(T6(:,k)<=TGT))) || T6(end-1,k) >TGT
            FE6=num;
            archive6=[archive6,T6(end,k)];
        else
            FE6=min((find(T6(:,k)<=TGT)));
        end
        
        rank=[rank;FE1,FE2,FE3,FE4,FE5,FE6];

    end
    
    
    RANK=[rank(:,1);rank(:,2);rank(:,3);rank(:,4);rank(:,5);rank(:,6)];
    [sorted_vector, indices] = sort(RANK);
    Rank = zeros(size(RANK));
    Rank(indices) = 1:numel(RANK);
    for i = 1:length(RANK)
        if RANK(i)==num
            Rank(i)=0;
        else
            Rank(i)=length(Rank)+1-Rank(i);
        end
    end
    
    sr=[sum(Rank(1:trial)),sum(Rank(trial+1:2*trial)),sum(Rank(2*trial+1:3*trial)),sum(Rank(3*trial+1:4*trial)),sum(Rank(4*trial+1:5*trial)),sum(Rank(5*trial+1:6*trial))];
    peak= sum(Rank~=0);
    
    if length(archive1)<trial
        archive1=[archive1,Inf.*ones(1,trial-length(archive1))];
    end
    
    if length(archive2)<trial
        archive2=[archive2,Inf.*ones(1,trial-length(archive2))];
    end
    
    if length(archive3)<trial
        archive3=[archive3,Inf.*ones(1,trial-length(archive3))];
    end
    
    if length(archive4)<trial
        archive4=[archive4,Inf.*ones(1,trial-length(archive4))];
    end
    
    if length(archive5)<trial
        archive5=[archive5,Inf.*ones(1,trial-length(archive5))];
    end
    
     if length(archive6)<trial
        archive6=[archive6,Inf.*ones(1,trial-length(archive6))];
     end
    
    ARCHIVE=[archive1,archive2,archive3,archive4,archive5,archive6];
    [sorted_vector, indices] = sort(ARCHIVE);
    arc = zeros(size(ARCHIVE));
    arc(indices) = 1:numel(ARCHIVE);

    arc=arc+peak;
    arc=length(arc)+1-arc;
    arc(arc<0)=0;
    
    arc=[sum(arc(1:trial)),sum(arc(trial+1:2*trial)),sum(arc(2*trial+1:3*trial)),sum(arc(3*trial+1:4*trial)),sum(arc(4*trial+1:5*trial)),sum(arc(5*trial+1:6*trial))];
    sr=sr+arc;
    [sorted_vector, indices] = sort(sr);
    rank = zeros(size(sr));
    rank(indices) = 1:numel(sr);
    SR=[SR;rank];
    sr=sr-cf;
    score=[score;sr];
end
sum(SR)