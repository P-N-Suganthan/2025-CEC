clc
clear all

for i = 1 : 15
    a{1} = load(['G:\结果\DESDE_SDC',num2str(i),'.mat']);
    a{2} = load(['G:\结果\CCPTEA_SDC',num2str(i),'.mat']);
    a{3} = load(['G:\结果\CCMET_SDC',num2str(i),'.mat']);
    a{4} = load(['G:\结果\IMTCMO_SDC',num2str(i),'.mat']);
    a{5} = load(['G:\结果\MTCMMO_SDC',num2str(i),'.mat']);

    %先计算最小IGD值
    for hh = 1 : 5
        for j = 1 : 30
            data(j+30*(hh-1),1) = hh;
            data(j+30*(hh-1),2) = j;
            data(j+30*(hh-1),3) = a{hh}.Run(end, (j-1)*2+1);
        end
    end

    num_IGD = size(data,1);

    [sort_IGD,sort_index] = sort(data(:,end));
    data2 = data(sort_index,:);
    median_IGD =  data2(num_IGD/2,end);
    %% 第一部分，横线上的解，对应没有使用完FES，这部分运行需要 找到1000代中 最接近median_IGD的值

    heng_data = data2(1:size(data2,1)/2,:);
    for c = 1 : size(heng_data,1)
        % 第一步，先找到对应的算法 运行次数 的所有IGD值
        run_data = a{heng_data(c,1)}.Run;
        all_IGD = run_data(:,(heng_data(c,2)-1)*2+1);
        index = find(all_IGD<=median_IGD);
        heng_data(c,4) = index(end)*200;
    end
    % 第二步，对这些解的FES进行排序

    [~,sort_index] = sort(heng_data(:,4));
    [~,a2] = sort(sort_index);
    heng_data(:,5) = a2;


    % 第二部分，竖线上的解，只需计算最后一代的IGD，比大小
    shu_data = data2(1+size(data2,1)/2:size(data2,1),:);
    % 数据拆分，Nan的放一起，比CV，非nan的放一起，比FES

    feinan_index = find(~isnan(shu_data(:,3))==1);
    shu1_data = shu_data( feinan_index,:);
    [~,sort_index] = sort(shu1_data(:,3));
    [~,a2] = sort(sort_index);
    shu1_data(:,5) = a2 + num_IGD/2;


    shu2_data = [];

    nan_index = find(isnan(shu_data(:,3))==1);
    if ~isempty(nan_index)
        shu2_data = shu_data( nan_index,:);
        for hh = 1 : length(nan_index)
            run_data = a{shu2_data(hh,1)}.Run;
            all_CV = run_data(:,(shu2_data(hh,2)-1)*2+2);
            shu2_data(hh,4) = all_CV(end);
        end
        [~,sort_index] = sort(shu2_data(:,4));
        [~,a2] = sort(sort_index,'descend');
        shu2_data(:,5) = num_IGD - a2+1;
    
    end

   

    %% 第三步 合并数据，统计结果

    hebing_data = [heng_data;shu1_data;shu2_data];
    hebing_data(:,5) = 151 - hebing_data(:,5);
    for hh = 1 : length(a)
        find_index = find(hebing_data(:,1)==hh);
        Final(i,hh) = sum(hebing_data(find_index,5));
    end

end

xishu = 30*(30+1)/2;
Final = Final - xishu;
sum(Final,1)